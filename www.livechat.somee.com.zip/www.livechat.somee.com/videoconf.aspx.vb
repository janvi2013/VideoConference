﻿
Partial Class videoconf
    Inherits System.Web.UI.Page

End Class
