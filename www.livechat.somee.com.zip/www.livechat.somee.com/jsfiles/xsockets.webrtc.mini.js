﻿XSockets.WebRTC = function (j, f) {
    var p = this;
    var h;
    this.PeerConnections = {};
    this.DataChannels = {};
    var g = {
        onPeerConnectionCreated: function () { },
        onDataChannelOpen: function () { },
        onDataChannelClose: function () { },
        onRemoteStream: function () {
            console.warning("There is no event handler attached for onRemoteStream")
        }
    };
    var q = XSockets.Utils.extend(g, f);
    var e = q.onLocalStream;
    var m = q.onContextChange;
    var k = q.onRemoteStream;
    var o = q.onContextCreated;
    var i = q.onPeerConnectionCreated;
    var n = q.onDataChannelOpen;
    var l = q.onDataChannelClose;
    var b = (function () {
        var t = [];
        this.add = function (v, y, w) {
            v = v.toLowerCase();
            var u = this.get(v);
            if (u === null) {
                var x = new r(v);
                x.addCallback(y, w);
                t.push(x);
                return 1
            }
            u.addCallback(y, w);
            return u.Callbacks.length
        };
        this.get = function (u) {
            u = u.toLowerCase();
            for (var v = 0; v < t.length; v++) {
                if (t[v].Name === u) {
                    return t[v]
                }
            }
            return null
        };
        this.getAll = function () {
            return t
        };
        this.remove = function (v, u) {
            v = v.toLowerCase();
            for (var w = 0; w < t.length; w++) {
                if (t[w].Name === v) {
                    if (u === undefined) {
                        t.splice(w, 1)
                    } else {
                        t[w].Callbacks.splice(u - 1, 1);
                        if (t[w].Callbacks.length === 0) {
                            t.splice(w, 1)
                        }
                    }
                    return true
                }
            }
            return false
        };
        this.fire = function (w, y, u, v) {
            w = w.toLowerCase();
            for (var x = 0; x < t.length; x++) {
                if (t[x].Name === w) {
                    if (v === undefined) {
                        t[x].fireCallbacks(y, u)
                    } else {
                        t[x].fireCallback(y, u, v)
                    }
                }
            }
        };
        var r = function (u) {
            this.Name = u;
            this.Callbacks = [];
            this.addCallback = function (w, v) {
                this.Callbacks.push(new s(w, v))
            };
            this.fireCallback = function (x, v, w) {
                this.Callbacks[w - 1].fn(x);
                if (typeof (this.Callbacks[w - 1].state) === "object") {
                    if (typeof (this.Callbacks[w - 1].state.options) !== "undefined" && typeof (this.Callbacks[w - 1].state.options.counter) !== "undefined") {
                        this.Callbacks[w - 1].state.options.counter.messages--;
                        if (this.Callbacks[w - 1].state.options.counter.messages === 0) {
                            if (typeof (this.Callbacks[w - 1].state.options.counter.completed) === "function") {
                                this.Callbacks[w - 1].state.options.counter.completed()
                            }
                        }
                    }
                }
                if (v && typeof (v) === "function") {
                    v()
                }
            };
            this.fireCallbacks = function (w, v) {
                for (var x = 0; x < this.Callbacks.length; x++) {
                    this.fireCallback(w, v, x + 1)
                }
            }
        };
        var s = function (v, u) {
            this.fn = v;
            this.state = u
        };
        return this
    });
    this.bind = function (t, r, s, u) {
        a.add(t, r);
        if (u && typeof (u) === "function") {
            u()
        }
    };
    this.unbind = function (r, s) {
        a.remove(r);
        if (s && typeof (s) === "function") {
            s()
        }
    };
    this.dispatch = function (r, t, s) {
        if (a.get(r) === null) {
            console.log("this", r, a.getAll());
            return
        }
        if (typeof t === "string") {
            t = JSON.parse(t)
        }
        a.fire(r, t, function () { })
    };
    var d = {
        iceServers: [{
            url: "stun:stun.l.google.com:19302"
        }]
    };
    var a = new b();
    this.channelPublish = function (u, r) {
        for (var v in p.DataChannels) {
            var t = p.DataChannels[v];
            if (t.readyState === "open") {
                var s = new XSockets.Message(u, r);
                t.send(JSON.stringify(s))
            }
        }
    };
    this.closeChannel = function (r) {
        p.DataChannels[r].close()
    };
    this.channelSubscribe = function (r, s, t) {
        p.bind(s + r, t)
    };
    this.channelUnsubscribe = function (r, s, t) {
        p.unbind(s + r, t)
    };
    var c = function (s) {
        var t = this;
        this.ClientGuid = s;
        this.RTCPeerConnection = new RTCPeerConnection(d, {
            optional: [{
                RtpDataChannels: true
            }]
        });
        this.RTCPeerConnection.onconnection = function () { };
        try {
            p.DataChannels[s] = this.RTCPeerConnection.createDataChannel("RTCDataChannel", {
                reliable: false
            });
            p.DataChannels[s].onmessage = function (v) {
                var u = JSON.parse(v.data)
                    .JSON;
                p.dispatch(t.ClientGuid + u.event, u.data, t.ClientGuid)
            };
            p.DataChannels[s].onopen = function () {
                n(p.DataChannels[s])
            };
            p.DataChannels[s].onclose = function () {
                l(p.DataChannels[s])
            }
        } catch (r) {
            console.log("'Create Data channel failed with exception:", r.message)
        }
        this.RTCPeerConnection.onstatechange = function (u) { };
        this.RTCPeerConnection.onaddstream = function (u) {
            k(u, s)
        };
        this.RTCPeerConnection.onicecandidate = function (v) {
            if (v.candidate) {
                var u = {
                    type: "candidate",
                    label: v.candidate.sdpMLineIndex,
                    id: v.candidate.sdpMid,
                    candidate: v.candidate.candidate
                };
                j.trigger("contextsignal", {
                    sender: p.CurrentContext.ClientGuid,
                    recipient: s,
                    message: JSON.stringify(u)
                })
            }
        };
        i(t.ClientGuid)
    };
    p.bind("connect", function (r) {
        p.PeerConnections[r.ClientGuid] = new c(r.ClientGuid);
        if (h) {
            p.PeerConnections[r.ClientGuid].RTCPeerConnection.addStream(h)
        }
        p.PeerConnections[r.ClientGuid].RTCPeerConnection.createOffer(function (s) {
            p.PeerConnections[r.ClientGuid].RTCPeerConnection.setLocalDescription(s);
            j.trigger("contextsignal", {
                sender: p.CurrentContext.ClientGuid,
                recipient: r.ClientGuid,
                message: JSON.stringify(s)
            })
        }, null, {
            mandatory: {
                OfferToReceiveAudio: true,
                OfferToReceiveVideo: true
            }
        })
    });
    p.bind("candidate", function (s) {
        var r = JSON.parse(s.Message);
        p.PeerConnections[s.Sender].RTCPeerConnection.addIceCandidate(new RTCIceCandidate({
            sdpMLineIndex: r.label,
            candidate: r.candidate
        }))
    });
    p.bind("answer", function (r) {
        p.PeerConnections[r.Sender].RTCPeerConnection.setRemoteDescription(new RTCSessionDescription(JSON.parse(r.Message)))
    });
    p.bind("offer", function (r) {
        p.PeerConnections[r.Sender] = new c(r.Sender);
        p.PeerConnections[r.Sender].RTCPeerConnection.setRemoteDescription(new RTCSessionDescription(JSON.parse(r.Message)));
        if (h) {
            p.PeerConnections[r.Sender].RTCPeerConnection.addStream(h)
        }
        p.PeerConnections[r.Sender].RTCPeerConnection.createAnswer(function (s) {
            p.PeerConnections[r.Sender].RTCPeerConnection.setLocalDescription(s);
            j.trigger("contextsignal", {
                sender: p.CurrentContext.ClientGuid,
                recipient: r.Sender,
                message: JSON.stringify(s)
            })
        }, null, {
            mandatory: {
                OfferToReceiveAudio: true,
                OfferToReceiveVideo: true
            }
        })
    });
    j.subscribe("contextCreated", function (r) {
        p.CurrentContext = new XSockets.PeerContext(r.ClientGuid, r.Context);
        o(r)
    });
    j.subscribe("signal", function (r) {
        var s = JSON.parse(r.Message);
        p.dispatch(s.type, r)
    });
    j.subscribe("contextChange", m);
    j.subscribe("connectTo", function (r) {
        r.forEach(function (s) {
            p.dispatch("connect", s)
        })
    });
    this.createChannel = function (r) { };
    this.changeContext = function (r) {
        j.trigger("ChangeContext", {
            guid: r
        })
    };
    this.getUserMedia = function (r, s) {
        console.log("userMediaSettings", r);
        window.getUserMedia(r, function (t) {
            h = t;
            e(t);
            if (s && typeof (s) === "function") {
                s(p.CurrentContext)
            }
        })
    }
};
XSockets.PeerContext = function (a, b) {
    this.ClientGuid = a;
    this.Context = b
};
var codecs = (function () {
    function b(e) {
        var h = e.split("\r\n");
        for (var g = 0; g < h.length; g++) {
            if (h[g].search("m=audio") !== -1) {
                var j = g;
                break
            }
        }
        if (j === null) {
            return e
        }
        for (var g = 0; g < h.length; g++) {
            if (h[g].search("opus/48000") !== -1) {
                var f = c(h[g], /:(\d+) opus\/48000/i);
                if (f) {
                    h[j] = a(h[j], f)
                }
                break
            }
        }
        h = d(h, j);
        e = h.join("\r\n");
        return e
    }
    function c(f, g) {
        var e = f.match(g);
        return (e && e.length == 2) ? e[1] : null
    }
    function a(f, j) {
        var h = f.split(" ");
        var k = new Array();
        var e = 0;
        for (var g = 0; g < h.length; g++) {
            if (e === 3) {
                k[e++] = j
            }
            if (h[g] !== j) {
                k[e++] = h[g]
            }
        }
        return k.join(" ")
    }
    function d(f, k) {
        var h = f[k].split(" ");
        for (var e = f.length - 1; e >= 0; e--) {
            var j = c(f[e], /a=rtpmap:(\d+) CN\/\d+/i);
            if (j) {
                var g = h.indexOf(j);
                if (g !== -1) {
                    h.splice(g, 1)
                }
                f.splice(e, 1)
            }
        }
        f[k] = h.join(" ");
        return f
    }
    return {
        preferOpus: b
    }
}());